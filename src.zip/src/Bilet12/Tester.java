package Bilet12;

public class Tester {
}
