package Bilet23;

public enum ShapeType {
    RECTANGLE,
    CIRCLE
}
