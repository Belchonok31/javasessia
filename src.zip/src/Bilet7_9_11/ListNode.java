package Bilet7_9_11;

public class ListNode {
    public int data;
    public ListNode next = null;

    public ListNode(int data) {
        this.data = data;
    }
}
