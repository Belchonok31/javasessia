package Bilet24;

public enum NumberType {
    RATIONAL, COMPLEX
}
